﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NAudio.Wave;
namespace alarma
{
    public class sonido
    {
        static string[] alarmaeme = { "alarma emergencia" };
        public static void alarma()
        {
            for (int i = 0; i < alarmaeme.Length; i++)
            {
                WaveOutEvent rep = new WaveOutEvent();
                AudioFileReader ubicacion = new AudioFileReader("alarmaemerg.MP3");
                rep.Init(ubicacion);
                rep.Play();
            }
        }
    }
}
